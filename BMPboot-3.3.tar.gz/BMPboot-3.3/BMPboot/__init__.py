print('Hi, I am BMPboot package, and I am ready to work!')
#może być pusty ... ale musi być!