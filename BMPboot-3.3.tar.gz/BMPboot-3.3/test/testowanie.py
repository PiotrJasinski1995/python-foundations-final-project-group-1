from BMPboot import main

main.main()
{}

#Ten test zostanie wykonany z zainstalowanej biblioteki BMPboot
# np. z C:\Users\Bartek\AppData\Local\Programs\Python\Python312\Lib\site-packages\BMPboot